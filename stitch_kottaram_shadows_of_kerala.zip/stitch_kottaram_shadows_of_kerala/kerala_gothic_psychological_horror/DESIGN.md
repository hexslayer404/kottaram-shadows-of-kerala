---
name: Kerala Gothic Psychological Horror
colors:
  surface: '#0f1418'
  surface-dim: '#0f1418'
  surface-bright: '#353a3e'
  surface-container-lowest: '#0a0f13'
  surface-container-low: '#171c20'
  surface-container: '#1b2024'
  surface-container-high: '#262b2f'
  surface-container-highest: '#30353a'
  on-surface: '#dfe3e9'
  on-surface-variant: '#dbc1bc'
  inverse-surface: '#dfe3e9'
  inverse-on-surface: '#2c3135'
  outline: '#a38b87'
  outline-variant: '#55423f'
  surface-tint: '#ffb4a6'
  primary: '#ffb4a6'
  on-primary: '#5d180c'
  primary-container: '#8b3a2b'
  on-primary-container: '#ffb6a7'
  inverse-primary: '#994535'
  secondary: '#eec14b'
  on-secondary: '#3e2e00'
  secondary-container: '#b38b14'
  on-secondary-container: '#362800'
  tertiary: '#adcfb4'
  on-tertiary: '#193624'
  tertiary-container: '#3c5a45'
  on-tertiary-container: '#afd0b5'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad3'
  primary-fixed-dim: '#ffb4a6'
  on-primary-fixed: '#3f0300'
  on-primary-fixed-variant: '#7b2e20'
  secondary-fixed: '#ffdf98'
  secondary-fixed-dim: '#eec14b'
  on-secondary-fixed: '#251a00'
  on-secondary-fixed-variant: '#5a4300'
  tertiary-fixed: '#c9ebcf'
  tertiary-fixed-dim: '#adcfb4'
  on-tertiary-fixed: '#032110'
  on-tertiary-fixed-variant: '#304d39'
  background: '#0f1418'
  on-background: '#dfe3e9'
  surface-variant: '#30353a'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  display-md:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.01em
  display-md-mobile:
    fontFamily: Playfair Display
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: 0em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: 0em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 30px
    letterSpacing: 0.01em
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 26px
    letterSpacing: 0.02em
  title-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0.01em
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 22px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.1em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 9px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.12em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  gutter-desktop: 1.5rem
  margin: 1.25rem
  margin-mobile: 1rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system translates the oppressive atmospheric density of an ancient Kerala ancestral estate (*tharavadu*) during the Southwest monsoon into an interactive companion interface. The visual language balances grounded photorealistic tactile realism with psychological dread and ritualistic decay.

The aesthetic philosophy rejects generic Western gothic tropes in favor of regional authenticity: saturated laterite stone, waterlogged teak wood, decaying brass locks, moss-choked courtyards, and supernatural folkloric stillness. The interface functions as an in-world diegetic survival artifact—a water-damaged field record, ritual parchment, and analog frequency scanner.

Key stylistic principles:
- **Diegetic Materiality:** Interactive surfaces take inspiration from tactile physical materials—wet laterite (*vettukallu*), oxidized brass charms (*thayathu*), and soaked archival paper.
- **Atmospheric Degradation:** Subtle analog grain, chromatic aberration, condensation layers, and vignette framing build tension without impeding functional utility.
- **Psychological Negative Space:** Deep shadows and claustrophobic framing deliberately withhold visual clarity, matching the survival mechanics of limited visibility and scarce light.

## Colors

The palette is derived directly from the architectural and environmental realities of rural Kerala drenched in torrential monsoon. 

- **Primary (`#8B3A2B` Laterite Clay & `#5C1D13` Dried Blood / Deep Laterite):** The dominant thematic color. Used for high-stakes psychological prompts, sanity anomalies, severe injury indicators, and primary action confirmation.
- **Secondary (`#C59B27` Oxidized Brass & `#846513` Antique Patina):** Evokes old temple bells, talismans, and flickering oil lamps (*nilavilakku*). Used for valuable objectives, relics, lore unlocks, and active states.
- **Tertiary (`#2D4A36` Monsoon Overgrowth & `#17281D` Swamp Canopy):** Represents encroaching nature and physical hazards. Used for environmental tracking, stamina gauges, and stealth indicators.
- **Neutral (`#0F1418` Midnight Slate & `#1E262C` Wet Asphalt):** Deep, low-chroma slate blacks that mimic rain-slicked stones at midnight. Serves as canvas backgrounds and primary structural containers.
- **Accents:**
  - **Incandescent Tungsten (`#E5A93C`):** Fragile artificial light, active torchlight, and interactive terminal prompts.
  - **Yakshi Mist (`#D4E0E8` & `#8FA4B5`):** Ethereal apparitions, frequency interference, radio static, and secondary text contrast against absolute darks.

## Typography

Typography balances architectural heritage, folkloric weight, and survival interface efficiency through three distinct typographical roles:

1. **Editorial & Folkloric Headlines (Playfair Display):**
   High-contrast, razor-sharp serifs give chapter headers, manor locations, ritual names, and diary entries an imposing, historical weight. When paired with Malayalam regional typography, character line-heights are expanded by 10% to prevent diacritic clipping.
2. **Tactical & Narrative Body (Inter):**
   Neutral, humanistic sans-serif ensures effortless readability under low-light screen conditions, small display viewports, and high-stress gameplay moments (e.g., inventory management, field lore, subtitles).
3. **Diegetic Instruments & Gauges (JetBrains Mono):**
   Monospaced technical typefaces drive radio frequency readouts, cassette tape timecodes, flashlight voltage, compass coordinates, and sanity metrics. Always rendered in tabular numerals (`tnum`) to avoid layout jitter during live-variable shifts.

## Layout & Spacing

The layout model utilizes a fluid 12-column grid on desktop screens, an 8-column layout on tablets, and a 4-column column structure on mobile viewports.

The rhythm is designed around claustrophobic density juxtaposed with isolated focal points:
- **Tight Micro-Spacings (`space-xs`, `space-sm`):** Dense inventory slots, radio telemetry readouts, and tactical status rows sit close together, simulating an analog, packed survival kit.
- **Atmospheric Framing (`margin-desktop`, `space-xl`):** Primary display viewports and narrative intros use generous empty space filled with subtle vignette overlays to focus the user's attention into the center of the dark canvas.
- **Safe Zones:** Mobile layouts enforce a strictly maintained bottom thumb-reach zone (minimum 72px clearance above the home indicator) for critical survival actions such as lantern toggle, quick-heal, and radio scan.

## Elevation & Depth

This system avoids synthetic drop shadows in favor of physical lighting logic and atmospheric layering:

1. **Tonal Surface Stacking:**
   - **Canvas Bottom (`#0F1418`):** Deep monsoon slate base.
   - **Mid-Tier Surfaces (`#161D22` with 80% opacity):** Heavy teak and stone container cards.
   - **Floating Interactive Layers (`#1E262C` with 95% opacity):** Inspectable items, puzzle drawers, and inventory panels.
2. **Low-Contrast Ghost Outlines:**
   Panels do not use heavy dropshadows; instead, they employ hair-thin 1px borders using `#C59B27` (antique brass at 12–25% opacity) or `#8FA4B5` (mist silver at 10% opacity) to catch edge highlights like damp wood and wet stone in low light.
3. **Diegetic Vignette & Mist Depth:**
   Overlays rely on multi-stop radial gradients: `radial-gradient(circle at center, transparent 40%, rgba(15, 20, 24, 0.85) 90%, #0F1418 100%)`. This draws user focus inward and simulates flashlight cone coverage.

## Shapes

The design uses a soft, grounded shape language (`roundedness: 1`). Radii stay tight (`0.25rem` / `4px` default, `0.5rem` / `8px` for larger cards) to evoke chisel-cut laterite blocks, framed ancestral portraits, and aged brass lockboxes. 

Pill shapes and modern high-radius bubbles are strictly forbidden, as they undermine the antique, tactile realism. Certain diegetic components—such as talisman markers, cassette tape labels, and compass bezels—employ clipped 45-degree chamfered corners (`polygon` clipping) to reflect hand-carved wood and hammered metal plates.

## Components

### 1. Buttons & Triggers
- **Primary Ritual Action:** Deep laterite red background (`#8B3A2B`), crisp brass hairline border (`#C59B27` at 40%), high-legibility uppercase monospaced text (`label-md`). Hover/Active states trigger an incandescent yellow glow (`#E5A93C`) bleed around the perimeter.
- **Secondary Ghost Action:** Semi-translucent dark slate fill (`#1E262C` at 50%), bordered by oxidized brass tint. Subtle scanline or water-ripple transition on tap.
- **Destructive / Panic Trigger:** Flashing dried-blood red (`#5C1D13`) fill with Yakshi silver high-contrast text, accompanied by analog static noise distortion.

### 2. Cards & Dossiers
- Constructed with wet slate surfaces (`#161D22`), faint lateral teak wood grain textures at 3% opacity, and 1px brass borders.
- Header bands incorporate a subtle distressed brass accent bar (2px height) along the top edge.

### 3. Inventory & Talisman Grid Slots
- Rigid 1:1 aspect ratio square containers with 4px border radii.
- Empty states feature an etched Malayalam numerical glyph or protective yantra silhouette in low-opacity moss slate (`#2D4A36` at 30%).
- Equipped or active items radiate an incandescent tungsten rim-light.

### 4. Chips & Metric Badges
- Compact indicators utilizing `label-sm` monospaced lettering.
- Pill shapes are replaced by rectangular badges with 2px corner radius.
- Sanity chips dynamically shift border color from antique brass (`#C59B27`, stable) to moss green (`#2D4A36`, disoriented) to laterite red (`#8B3A2B`, panicked).

### 5. Input Fields & Frequency Dials
- Underlined or recessed dark trough design (`#0F1418`) with 1px border at bottom edge.
- Cursor is an analog blinking amber-yellow block (`#E5A93C`).
- Companion radio/tuner input uses a horizontally scrollable analog frequency band with tick marks and static frequency waveforms.

### 6. Checkboxes & Toggles
- Custom brass clasp checkboxes that show an oxidized antique crossmark or talisman lock icon when checked.
- Toggles resemble physical, weathered teak-and-brass slider switches with tactile click animations and mechanical movement soundscapes.